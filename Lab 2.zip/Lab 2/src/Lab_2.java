import java.util.Scanner;
public class Lab_2 {
public static void main(String[] args) {
	double width;
	double length;
	double area;
	double perimeter;
	boolean input = true;
	while (input == true) {
	Scanner inputWidth = new Scanner(System.in);
	System.out.printf("Input width: ");
	width = inputWidth.nextDouble();
	Scanner inputLength = new Scanner(System.in);
	System.out.printf("Input length: ");
	length = inputLength.nextDouble();
	
	perimeter = (width*2) + (length*2);
	area = (length * width);
	System.out.println("The Perimeter is: " +perimeter);
	System.out.println("The area is: " +area);
	
	
	Scanner inputAttempt = new Scanner(System.in);
	System.out.printf("Do you want to do another one: ");
	input = inputAttempt.next().startsWith("y");
	if(input == true) {
		input = true;
	}
	else {
	}
	
}
	
	System.out.println("have a nice day!!");
}
}
